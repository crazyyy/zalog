<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <title>Кредит под залог недвижимости</title>

  <!-- Start CSS -->
  <link rel="stylesheet" type="text/css" media="all" href="css/style.css">
  <!--[if IE]>
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->
</head>

<body>
  <div class="wrap">
    <header style="height: 367px;">
      <div class="content">
        <h1>Кредит под залог недвижимости</h1>

        <h2>Заполните анкету за <span class="c">45 секунд</span><br> и получи деньги на <span>следующий день:</span></h2>
        <ul>
          <li class="l1">Рассмотрение заявки в 2 часов</li>
          <li class="l2">Процентная ставка от 15% годовых</li>
          <li class="l3">Суммы от 400 тыс. до 20 млн.</li>
          <li class="l4">Срок кредита до 20 лет.</li>
        </ul>
        <h3>Нас <span>НЕ интересует</span>  ваша кредитная история, размер дохода и трудоустройство.</h3>

        <div class="girl"></div>
      </div>
    </header>
    <div class="line">
      <div class="content">
        <ul>
          <li class="l1 ok cur"><span>1</span> Старт</li>
          <li class="l2 "><span>2</span> Проживание</li>
          <li class="l3 "><span>3</span> Объект</li>
          <li class="l4 "><span>4</span> Личная информация</li>
        </ul>
      </div>
    </div>
    <section>
      <div class="content">
        <form action="data/form.php" method="POST" id="dataform">
          <div class="step step1">
            <div class="page">
              <div class="f f1">Необходимая сумма:</div>
              <div class="i i1">
                <input type="text" name="summ" value="800 000">
              </div>
              <div class="f f2">руб.</div>
              <div class="next">Далее</div>
            </div>


            <div class="infoblock">
              <div class="text">
                <p>
                  Кредит под залог:
                </p>
                <ul>
                  <li>квартиры</li>
                  <li>комнаты</li>
                  <li>загородного дома</li>
                  <li>земельного участка</li>
                  <li>коммерческой недвижимости</li>
                </ul>
              </div>
            </div>
          </div>

          <div class="step step2">
            <div class="page">
              <div class="f f1">Где вы проживаете:</div>
              <div class="i i1">
                <select name="region">
                  <option value="Москва">Москва</option>
                  <option value="Московская обл.">Московская обл.</option>
                </select>
              </div>
              <div class="c c1">
                <input type="checkbox" value="Регистрация в месте проживания" name="region_registration" id="reg" checked="">
                <label for="reg">Регистрация в месте проживания</label>
              </div>
              <div class="next">Далее</div>
            </div>


            <div class="infoblock">
              <div class="text">
                <p>
                  Работаем По ФЗ №102 "Об Ипотеке (залоге недвижимости)
                </p>
              </div>
            </div>
          </div>

          <div class="step step3">
            <div class="page">
              <div class="f f1">Выберите объект:</div>
              <div class="i i1">
                <select name="object_type" id="object_type_form_field">
                  <option selected="" value="apart">квартира</option>
                  <option value="room">комната</option>
                  <option value="proportion">доля</option>
                  <option value="country">загородный дом</option>
                  <option value="land">земельный участок</option>
                  <option value="commercial">коммерческая недвижимость</option>
                </select>
              </div>
              <div class="next">Далее</div>
            </div>


            <div class="infoblock">
              <div class="text">
                <p>
                  Выдаем:
                </p>
                <ul>
                  <li>Аванс в день обращения;</li>
                  <li>Полный расчет в день оформления.</li>
                </ul>
              </div>
            </div>
          </div>

          <div class="step step4">
            <div class="page">
              <div class="f f1">Имя:</div>
              <div class="f f2">Телефон:</div>
              <div class="f f3">E-mail:</div>
              <div class="f f4">Возраст:</div>
              <div class="i i1">
                <input type="text" name="name" value="">
              </div>
              <div class="i i2">
                <input type="text" name="phone" value="+7">
              </div>
              <div class="i i3">
                <input type="text" name="email" value="">
              </div>
              <div class="i i4">
                <select name="age">
                  <option value="18">18</option>
                  <option value="19">19</option>
                  <option value="20">20</option>
                  <option value="21">21</option>
                  <option value="22">22</option>
                  <option value="23">23</option>
                  <option value="24">24</option>
                  <option value="25">25</option>
                  <option value="26">26</option>
                  <option value="27">27</option>
                  <option value="28">28</option>
                  <option value="29">29</option>
                  <option value="30">30</option>
                  <option value="31">31</option>
                  <option value="32">32</option>
                  <option value="33">33</option>
                  <option value="34">34</option>
                  <option value="35">35</option>
                  <option value="36">36</option>
                  <option value="37">37</option>
                  <option value="38">38</option>
                  <option value="39">39</option>
                  <option value="40">40</option>
                  <option value="41">41</option>
                  <option value="42">42</option>
                  <option value="43">43</option>
                  <option value="44">44</option>
                  <option value="45">45</option>
                  <option value="46">46</option>
                  <option value="47">47</option>
                  <option value="48">48</option>
                  <option value="49">49</option>
                  <option value="50">50</option>
                  <option value="51">51</option>
                  <option value="52">52</option>
                  <option value="53">53</option>
                  <option value="54">54</option>
                  <option value="55">55</option>
                  <option value="56">56</option>
                  <option value="57">57</option>
                  <option value="58">58</option>
                  <option value="59">59</option>
                </select>
              </div>
              <input type="hidden" name="hidden" value="ok">
              <button type="submit" class="next">Далее</button>
            </div>


            <div class="infoblock">
              <div class="text">
                <p>
                  От вас не требуется подтверждение дохода и трудоустройства. Кредитная история НЕ имеет значения
                </p>
              </div>
            </div>
          </div>


          <div class="step step5">
            <div class="page">
              <div class="f">Спасибо! Наш консультант позвонит Вам в ближайшее время.</div>
              <div id="pixel"></div>
              <div class="c"></div>
            </div>
          </div>
        </form>
      </div>
    </section>
  </div>
  <footer>
    <div class="content clearfix">
      <div class="left">
        <span class="copy">ООО "Центр Финансового Сервиса"</span>
      </div>
      <div class="center">
        <ul class="cntct-lst">
          <li><span class="grey-txt">Адрес:</span> Москва ул. Ленинская Слобода д.17</li>
          <li><span class="grey-txt">Телефон:</span> 8 (495) 230-62-61</li>
        </ul>
      </div>
      <div class="right">
      </div>
    </div>
  </footer>


  <script src="js/jquery.js"></script>
  <script src="js/script.js"></script>

</body>
</html>

